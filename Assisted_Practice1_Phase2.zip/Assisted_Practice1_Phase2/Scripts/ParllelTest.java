package com.app.TestNG.Scripts;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class ParllelTest {

		
		@Test
		public void wikiPage() throws InterruptedException
		{
			System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Google\\Chrome\\Application\\chromedriver.exe");
			 WebDriver driver = new ChromeDriver();
			
			driver.get("https://en.wikipedia.org/w/index.php?title=Special:CreateAccount&returnto=Wikipedia%3ASign+up");
			
			Thread.sleep(1000);
			driver.close();
		}
		
		@Test
		public void wikiPage2() throws InterruptedException
		{
			System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Google\\Chrome\\Application\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			
			driver.get("https://en.wikipedia.org/w/index.php?title=Special:CreateAccount&returnto=Wikipedia%3ASign+up");
			
			Thread.sleep(1000);
			driver.close();
		}

		@Test
		public void ninjaPage() throws InterruptedException
		{
			System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Google\\Chrome\\Application\\chromedriver.exe");
			 WebDriver driver = new ChromeDriver();
			
			driver.get("https://tutorialsninja.com/demo/");
			
			Thread.sleep(1000);
			driver.close();
		}
		
		@Test
		public void ninjaPage2() throws InterruptedException
		{
			System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Google\\Chrome\\Application\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			driver.get("https://tutorialsninja.com/demo/");
			
			Thread.sleep(1000);
			driver.close();
		}
		

}
