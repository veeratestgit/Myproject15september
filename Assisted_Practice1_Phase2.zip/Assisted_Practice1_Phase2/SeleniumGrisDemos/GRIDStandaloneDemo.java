package com.app.SeleniumGrisDemos;

import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

public class GRIDStandaloneDemo {

	
	WebDriver driver;
	
	@Test
	public void GridDemo1() throws MalformedURLException
	{
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setBrowserName("chrome");
        capabilities.setPlatform(Platform.ANY);

		// and send your desired capapbilties to the hub to start a session on the node
		
		//ChromeOptions cap = new ChromeOptions();
		ChromeOptions options = new ChromeOptions();
        options.setBinary("C:\\Program Files\\Google\\Chrome\\Application\\chromedriver.exe");

        capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		// this RemoteWebDriver class will connect webdriver to HUb router
		//System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Google\\Chrome\\Application\\chromedriver.exe");
		driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"),options);
	
		driver.manage().window().maximize();
		driver.get("https://tutorialsninja.com/demo/");
		String title = driver.getTitle();
		System.out.println(title);
		
		
		
	}
	
	
	
}