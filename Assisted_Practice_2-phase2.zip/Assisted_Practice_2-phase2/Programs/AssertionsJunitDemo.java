package com.app.junitDemo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class AssertionsJunitDemo {
	
	@Test
	public void testAssetions() {
		String expected = new String("abcd");
		String actual = new String("abcd");
		String str3 = "junit";
		String str4 = null;
		int val1=20;
		int val2=30;
		
		Assertions.assertEquals(expected,actual);
		Assertions.assertTrue(val1<val2);//true
		Assertions.assertNotNull(str3);//here expected input should not be null
		Assertions.assertNull(str4);//here expected input should  be null
		//Assertions.assertSame(expected,val1);//check if 2 objects are same or not
		//Assertions.assertNotSame(expected,actual);//
	}

}
