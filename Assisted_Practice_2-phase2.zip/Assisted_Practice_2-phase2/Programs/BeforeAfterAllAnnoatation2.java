package com.app.junitDemo;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
//@testinstance will configure lifecycle of tests
//it hase 2 methods .perclass and .permethod)
@TestInstance(Lifecycle.PER_CLASS)
public class BeforeAfterAllAnnoatation2 {

		
		static JavaOperations obj;
		
		@BeforeAll  // execute the init() method before each test method
		public  void init() {   // pre condition method
			System.out.println("Start Db connection");
			 obj = new JavaOperations();
			 System.out.println("Initalization done..");
		}
		
		
		@AfterAll // execute teardown() method after each test method
		public  void teardown()  // post condition method
		{
			System.out.println("close DB connection");
		}
		
		@Test
		public void test1()
		{
			// create an object of a class and then execute the code
			System.out.println("Execute the test case using methods of ... JavaOperations");
			
		}
		
		@Test
		public void test2()
		{
			// create an object of a class and then execute the code
			System.out.println("Execute the test case using methods of ... JavaOperations");
			
		}


}
