package com.app.junitDemo;

public class DependencyInjectionDemo
{
	
	public void repeatestDemo()
	{
		
	}

}
