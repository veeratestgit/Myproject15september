package com.app.junitDemo;

import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

public class RepeatedtestDemo {
	//To execute this test 3 times
	@RepeatedTest(3)
	//to display name
	@DisplayName("RepeatedTest")
	public void repeatmessage()
	{
		System.out.println("we are learning junit");
	}
	
	@Test
	public void AssumptionDemo() 
	{
		// want to run the test case only if DB SERVER is up and running
		boolean isDBServerUp = true;
		Assumptions.assumeTrue(isDBServerUp,"server is not Up");
		System.out.println("Create table and insert data");
		
	}

}
