package com.app.junitDemo;

import org.junit.jupiter.api.Test;

//import org.junit.jupiter.api.Test;

public class TestAnnotation {
	//change the java library if you are not getting run as junit test
	
	//project>buildpath>configurebuild path>library>select jre>remove
	//add library> select JRE System library>click on 1st radio button>select correct java version
	@Test    //execute the below test
	public void Method1() {   //unit test method
		System.out.println("Hello world");
	}
	
}
