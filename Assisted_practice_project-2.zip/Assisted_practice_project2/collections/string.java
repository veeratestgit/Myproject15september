package collections;

public class string {

}
