package phase2project;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Starhealth002 {
	@Test
	public void print_link()
	{
		//WebDriver driver = new ChromeDriver();
		System.out.println("success the link is :https://starhealth.in");
	//String link1=	driver.findElement(By.linkText("Glossary")).getText();
	
	}

}
