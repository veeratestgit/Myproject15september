package com.app.TddDemo;


import java.util.HashMap;
import java.util.Map;

public class CourseSearch {
	

		private Map<String, Integer> getcoursedata() {
			
			Map<String, Integer> courseMap = new HashMap<>();
			courseMap.put("python", 100);
			courseMap.put("aws", 250);
			courseMap.put("JAVA", 300);
			courseMap.put("cloud", 500);
			

			return courseMap;
		}
		
		public int getcourse(String course) {
			
			Map<String, Integer> courseMap = null ;
			int count =0;
			
			if(course.isEmpty())
			{
				throw new NullPointerException("course name cannot be empty");
			}
			courseMap = getcoursedata();
			
			if(!courseMap.containsKey(course))
			{
				throw new NullPointerException("course name doesnot exist");
			}
			else {
			count = courseMap.get(course);
			}
			return count;
			
		}

	}
