package com.app.TddDemo;


import org.testng.Assert;
import org.testng.annotations.Test;


public class TestcourseSearch {

	
	/
	@Test
	public void findcourseenrollment()
	{
		
		String course = "JAVA";
		int Expectedenrolment = 300;
		courseSearch ps = new courseSearch();
		
		// number of people in the city
		
		int count = ps.getcourse(course);
		
		System.out.println(count);
		
		Assert.assertEquals(count, Expectedenrolment);
		
	}
	
	@Test
	public void findcourseEmptyInput()
	{
		try {
		String course = "";
		int Expectedenrolment = 0;
		courseSearch ps = new courseSearch();
		
		// number of people in the city
		
		int count = ps.getcourse(course);
		}
		
		catch(NullPointerException e)
		{
			System.out.println("Course name cannot be empty");
		}
		
		
		
	}
	
	@Test
	public void findcourseInvalidInput()
	{
		try {
		String course = "python";
		int Expectedenrolment = 700;
		courseSearch ps = new courseSearch();
		
		// number of people in the city
		
		int count = ps.getcourse(course);
		}
		
		
		catch(NullPointerException e1)
		{
			System.out.println("Course name doesnot exisit in the list");
		}
		
		
		
		
		
		
	}

}
