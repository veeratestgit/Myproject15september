package com.app.facebooktest;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class Csv {
	
		// CSV => storing data in form of row and colums-> like an excel
		
		
			@ParameterizedTest(name = "CSV source {arguments}")
			@CsvSource({
					"Creta ,  25",  // row and column
					"Fortuner,   24",
					"Breeza, 45",
					"i20,  50"		
			})
			
			public void datafrom_CSVsource(String car, String quantity)
			{
				System.out.println(car+" : "+quantity);
			}


}
