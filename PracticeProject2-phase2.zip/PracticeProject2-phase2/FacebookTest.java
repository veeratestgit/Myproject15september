package com.app.facebooktest;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;

public class FacebookTest {

    private static WebDriver driver;

    @BeforeAll
    public static void startBrowser() {
        System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Google\\Chrome\\Application\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.facebook.com/");
    }

    @DisplayName("Facebook Login Test")
    @RepeatedTest(3)
    public void testFacebookLogin() throws InterruptedException, IOException {
        clearInputFields();
        TestMethod("your_username", "your_password");
        // Add assertions to verify successful login

        // Wait for 5 seconds before taking a screenshot
        Thread.sleep(5000);

        // Take a screenshot
        takeScreenshot();
    }

    @ParameterizedTest(name = "Parameterized Facebook Login Test - username: {0}, password: {1}")
    @CsvSource({
            "Admin1, Admin@321",
            "user2, user@321",
            "Adminuser3, Admer231"
    })
    public void testParameterizedFacebookLogin(String username, String password) throws InterruptedException, IOException {
        clearInputFields();
        TestMethod(username, password);
        // Add assertions to verify login with provided credentials

        // Wait for 5 seconds before taking a screenshot
        Thread.sleep(5000);

        // Take a screenshot
        takeScreenshot();
    }

    public void clearInputFields() {
        WebElement emailField = driver.findElement(By.cssSelector("input#email"));
        WebElement passwordField = driver.findElement(By.cssSelector("input[name='pass']"));

        emailField.clear();
        passwordField.clear();
    }

    public void TestMethod(String username, String pwd) {
        WebElement emailField = driver.findElement(By.cssSelector("input#email"));
        WebElement passwordField = driver.findElement(By.cssSelector("input[name='pass']"));

        emailField.sendKeys(username);
        passwordField.sendKeys(pwd);
    }

    public void takeScreenshot() throws IOException {
        // Cast WebDriver to TakesScreenshot
        TakesScreenshot screenshotDriver = (TakesScreenshot) driver;

        // Get the screenshot as a file
        File screenshotFile = screenshotDriver.getScreenshotAs(OutputType.FILE);

        // Save the file with a timestamp or any desired name
        // Example: File destFile = new File("screenshot_" + System.currentTimeMillis() + ".png");

        // You can use the timestamp to make the file name unique
        File destFile = new File("screenshot.png");

        // Copy the screenshot file to your desired location
        org.apache.commons.io.FileUtils.copyFile(screenshotFile, destFile);
    }

    @AfterAll
    public static void closeBrowser() {
        if (driver != null) {
            driver.quit();
        }
    }
}


