package com.app.Googletest;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.junit.jupiter.api.Assertions;

public class GoogleTest {

	    private static WebDriver driver;

	    @BeforeAll
	    public static void startBrowser() {
	        System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Google\\Chrome\\Application\\chromedriver.exe");
	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.get("https://www.google.com/");
	    }
	    @ParameterizedTest(name = "Search URL: {0}")
	    @CsvSource({
	            "https://www.simplilearn.com/",
	            "https://www.redbus.in/",
	            "https://www.amazon.com/"
	    })
	    public void testGoogleSearch(String url) {
	        clearSearchBox();
	        search(url);
	        
	        // Assertion 1: Check if the page title contains the query
	        String query = url.contains("simplilearn") ? "simplilearn" : url.contains("redbus") ? "redbus" : "amazon";
	        Assertions.assertTrue(driver.getTitle().toLowerCase().contains(query));

	        // Assertion 2: Check if search results are present
	        WebElement searchResults = driver.findElement(By.id("search"));
	        Assertions.assertNotNull(searchResults);
	    }


	    @AfterAll
	    public static void closeBrowser() {
	        if (driver != null) {
	            driver.quit();
	        }
	    }

	    public void clearSearchBox() {
	        WebElement searchBox = driver.findElement(By.name("q"));
	        searchBox.clear();
	    }

	    public void search(String query) {
	        WebElement searchBox = driver.findElement(By.name("q"));
	        searchBox.sendKeys(query);
	        searchBox.submit();
	    }
	}

