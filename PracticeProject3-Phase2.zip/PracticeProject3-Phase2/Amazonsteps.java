package steps;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Amazonsteps {

	    WebDriver driver;

	    public Amazonsteps() {
	        // Initialize your WebDriver instance, e.g., ChromeDriver
	    	System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Google\\Chrome\\Application\\chromedriver.exe");
			driver = new ChromeDriver();
			// You'll need to set up the WebDriver and navigate to Amazon's website here.
	    }

	    @Given("I am on the Amazon homepage")
	    public void i_am_on_the_amazon_homepage() {
	        // Navigate to the Amazon homepage
	    	
	        driver.get("https://www.amazon.com/");
	    }
	    

	    @When("I search for {string}")
	    public void i_search_for(String searchTerm) {
	        // Locate the search bar and enter the search term
	        WebElement searchBox = driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]"));
	        searchBox.sendKeys(searchTerm);
	        searchBox.submit();
	    }
	   
	    @Then("I should see search results")
	    public void i_should_see_search_results() {
	        // Check that search results are displayed, e.g., by checking for elements on the search results page.
	        assertTrue(driver.findElements(By.cssSelector(".s-result-list")).size() > 0);
	    }

	    @When("I click on the first search result")
	    public void i_click_on_the_first_search_result() {
	        // Click on the first search result
	        WebElement firstResult = driver.findElement(By.xpath("//*[@id=\"search\"]/div[1]/div[1]/div/span[1]/div[1]/div[2]/div/div/div/div/div/div/div/div[1]/div/div[2]/div/span/a/div/img"));
	        firstResult.click();
	    }
	    @When("I click on first search result")
	    public void i_click_on_the_first_search_result1() {
	        // Click on the first search result
	        WebElement firstResult = driver.findElement(By.xpath("//*[@id=\"search\"]/div[1]/div[1]/div/span[1]/div[1]/div[2]/div/div/div/div/div/div[1]/div/div[2]/div/span/a/div/img"));
	        firstResult.click();
	    }

	    @And("I add the item to the cart")
	    public void i_add_the_item_to_the_cart() {
	        // Implement logic to add the item to the cart, e.g., by clicking an "Add to Cart" button.
	        WebElement addToCartButton = driver.findElement(By.id("add-to-cart-button"));
	        addToCartButton.click();
	    }

	}

