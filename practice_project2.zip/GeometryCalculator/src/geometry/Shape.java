package geometry;

public class Shape {
    public void displayArea() {
        System.out.println("This is the base class for shapes.");
    }
}

